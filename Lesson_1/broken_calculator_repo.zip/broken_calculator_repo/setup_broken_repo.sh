#!/bin/bash

# Create broken calculator.py with all mixed up changes
cat > calculator.py << 'EOF'
# Calculator implementation
def add(a, b):
    return a + b

def subtract(a, b):
    # TODO: fix this bug later
    return a + b  # BUG: should be a - b

def multiply(a, b):
    # Not implemented
    pass

# Quick test
print("2 + 3 =", add(2, 3))
print("5 - 2 =", subtract(5, 2))  # This shows 7 instead of 3!

# My lunch break notes - DELETE THIS
# Had pizza today, was good

def divide(a, b):
    return a / b  # TODO: add zero check

# Unfinished advanced features
class Scientific:
    def sqrt(self, x):
        # TODO
        pass
EOF

# Create homework description
cat > HOMEWORK.md << 'EOF'
# Homework1 

## 🎯 Your Mission is fix this repo
A junior developer made a mess. Fix it using proper Git practices!

## 📁 Current State
- All changes dumped in one commit
- Useless commit messages ("fix", "update")
- Mixed features, bugs, and random comments
- No atomic commits

## ✅ Tasks

### 1. Split the Mess
Use `git add -p` to create atomic commits:
- [ ] Basic addition function
- [ ] Subtraction function (with bug)
- [ ] Bug fix for subtraction
- [ ] Division function
- [ ] Remove trash comments
- [ ] Add TODO for multiplication

### 2. Write Proper Commit Messages
Follow conventional commits:
```
feat: add basic addition function
fix: correct subtraction logic
refactor: remove unnecessary comments
```

### 3. Clean History
Use `git rebase -i` to:
- Reorder commits logically
- Squash related changes
- Edit commit messages

## 📋 Deliverables
1. Fork this repo
2. Fix the history
3. Submit PR with:
   - Clean, atomic commits
   - Meaningful messages
   - Logical commit order

## 🎓 Success Criteria
- Each commit does ONE thing
- `git log --oneline` tells a story
- Any commit can be reverted safely
- New developer understands project evolution

## 💡 Hint
Start fresh: `git reset --soft HEAD~1` to uncommit everything!
EOF

# Make first terrible commit
git add calculator.py
git commit -m "initial commit"

# Add more bad commits
echo "" >> calculator.py
echo "# FIXME: everything is broken" >> calculator.py
git add calculator.py
git commit -m "fix"

# Add homework file with another bad commit
git add HOMEWORK.md
git commit -m "update"

# Add one more useless change
sed -i '' 's/TODO/FIXME/g' calculator.py 2>/dev/null || sed -i 's/TODO/FIXME/g' calculator.py
git add calculator.py
git commit -m "changes"

# Show the mess we created
echo "✅ Broken repository created!"
echo ""
echo "📊 Current git history:"
git log --oneline
echo ""
echo "📁 Files in repo:"
ls -la
echo ""
echo "🎯 Now students need to fix this mess!"
EOF