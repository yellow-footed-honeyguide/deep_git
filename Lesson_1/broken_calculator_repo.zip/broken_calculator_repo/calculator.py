# Calculator implementation
def add(a, b):
    return a + b

def subtract(a, b):
    # FIXME: fix this bug later
    return a + b  # BUG: should be a - b

def multiply(a, b):
    # Not implemented
    pass

# Quick test
print("2 + 3 =", add(2, 3))
print("5 - 2 =", subtract(5, 2))  # This shows 7 instead of 3!

# My lunch break notes - DELETE THIS
# Had pizza today, was good

def divide(a, b):
    return a / b  # FIXME: add zero check

# Unfinished advanced features
class Scientific:
    def sqrt(self, x):
        # FIXME
        pass

# FIXME: everything is broken
