const calc = require('./calculator');

// Test all functions
console.log("Add:", calc.add(10, 5));
console.log("Subtract:", calc.subtract(10, 5));
console.log("Multiply:", calc.multiply(10, 5));
console.log("Divide:", calc.divide(10, 5));
console.log("Divide by zero:", calc.divide(10, 0)); // This will return Infinity!
console.log("Square root of 16:", calc.sqrt(16));
console.log("20% of 150:", calc.percentage(150, 20));
