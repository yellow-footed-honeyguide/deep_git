// Calculator module
function add(a, b) {
    return a + b;
}

function subtract(a, b) {
    return a - b;
}

function multiply(a, b) {
    return a * b;
}

function divide(a, b) {
    return a / b;  // TODO: This will break with zero!
}

// New features added here
function sqrt(a) {
    return Math.sqrt(a);
}

function percentage(value, percent) {
    return (value * percent) / 100;
}

// Logging for debugging
function logOperation(op, a, b, result) {
    console.log(`${op}: ${a}, ${b} = ${result}`);
}

module.exports = { add, subtract, multiply, divide, sqrt, percentage, logOperation };
