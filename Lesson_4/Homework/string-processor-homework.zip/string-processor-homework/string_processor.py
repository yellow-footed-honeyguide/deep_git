def reverse_string(s):
    """Reverse a string"""
    return s[::-1]

def count_vowels(s):
    """Count vowels in string"""
    vowels = 'aeiouAEIOU'
    return sum(1 for char in s if char in vowels)

def capitalize_words(s):
    """Capitalize each word in string"""
    return ' '.join(word.capitalize() for word in s.split())

def is_palindrome(s):
    """Check if string is palindrome"""
    return s == s[::-1]  # BUG REAPPEARED!

# New functions
def truncate(s, length=50, suffix='...'):
    """Truncate string with ellipsis"""
    if len(s) <= length:
        return s
    return s[:length-len(suffix)] + suffix

def extract_emails(s):
    """Extract emails from text"""
    import re
    return re.findall(r'\b[\w.-]+@[\w.-]+\.\w+\b', s)
