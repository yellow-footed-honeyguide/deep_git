from string_processor import *

print("Reverse 'hello':", reverse_string('hello'))
print("Is palindrome 'Anna':", is_palindrome('Anna'))  # Will fail!
print("Truncate long text:", truncate("This is a very long string that needs truncation"))
