console.log("Hello");
function init() { console.log("App started"); }
init();
